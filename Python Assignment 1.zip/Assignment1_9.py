def Display():
    
    data = range(2,22,2)
    for no in data:
        print(no)

def main():
    
    Display()

if __name__ == "__main__":
    main()