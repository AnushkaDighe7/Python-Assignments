def Display():
    data = range(5)
    for no in data:
        print("Marvellous")

def main():
    Display()

if __name__ == "__main__":
    main()