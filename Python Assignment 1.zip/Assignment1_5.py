def Display():
    
    data = range(10,0,-1)
    for no in data:
        print(no)

def main():
    
    Display()

if __name__ == "__main__":
    main()