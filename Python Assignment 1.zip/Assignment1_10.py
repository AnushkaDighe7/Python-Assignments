

def main():
    
    name = input("Enter the Name: ")
    
    print("Length of Name is",len(name))


if __name__ == "__main__":
    main()
